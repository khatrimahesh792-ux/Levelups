LEVEL UPS - ANDROID APP PROJECT
===============================

This is an Android Studio project. The app is a WebView wrapper around the
Level Ups web app, stored at app/src/main/assets/index.html.

Requirements: latest Android Studio (includes the JDK it needs).
Minimum Android version: 7.0 (API 24).

1) OPEN THE PROJECT
   Unzip the folder. In Android Studio choose File > Open and select the
   LevelUps_Android folder. Wait for the Gradle sync to finish (the first
   time it downloads a lot of files, so it can take a few minutes).
   If Android Studio offers to upgrade Gradle or the Android Gradle Plugin,
   accept it.

2) TEST ON YOUR PHONE
   On the phone, enable Developer options and USB debugging. Connect the
   phone and press the green Run button.

3) BUILD AN APK (to install or share)
   Build > Build App Bundle(s) / APK(s) > Build APK(s)
   The file will be at: app/build/outputs/apk/debug/app-debug.apk

4) BUILD A SIGNED RELEASE FOR THE PLAY STORE
   Build > Generate Signed App Bundle / APK > Android App Bundle
   Create a new keystore the first time. Keep the keystore file and its
   passwords safe. You need the SAME keystore for every future update.
   The output is an .aab file, which is what Google Play requires.

5) APP ICON (optional)
   Right-click the app folder > New > Image Asset, and choose your icon.

TO UPDATE THE APP LATER
   Replace app/src/main/assets/index.html with the new version of the web
   app, then build again.

WHAT WORKS IN THE APK VERSION
   - The whole app works offline. Progress is saved on the phone.
   - Choosing a profile photo works (through the phone's photo picker).

WHAT DOES NOT WORK YET IN THE APK VERSION
   - Global leaderboard: needs an online backend (for example Firebase).
     Until then the Rank tab shows "not connected".
   - Daily reminder notifications: browser notifications are not available
     inside the app. They need native Android code (AlarmManager and
     NotificationManager).
